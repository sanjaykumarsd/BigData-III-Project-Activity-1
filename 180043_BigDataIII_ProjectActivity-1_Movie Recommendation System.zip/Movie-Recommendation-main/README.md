
# Movie Recommendation System 
Bipin Singh

How to run?

1. Install Java Dependencies using Maven or IDE 
2. Run Java source code
3. Go to client folder and run
```s
npm install
```
4. Run the frontend using
```
npm run dev
```


## Screenshots

![App Screenshot](ss.png)

